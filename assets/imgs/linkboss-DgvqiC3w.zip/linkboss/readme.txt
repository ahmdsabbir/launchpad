=== LinkBoss ===
Plugin Name: LinkBoss (Smartest Ever Interlinking Tool)
Version: 2.1.0
Author: linkboss
Author URI: 
Contributors: linkboss, bdkoder, samiurprapon
Requires at least: 5.2
Tested up to: 6.4.1
Stable tag: 2.1.0
Requires PHP: 7.2
