<?php
/**
 * Trait Global Functions
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss\Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description of Global Functions
 * 
 * @since 0.0.0
 */
trait Global_Functions {

	/**
	 * Fetch Reports from the server
	 * 
	 * @since 0.0.0
	 */
	public function fetch_reports() {
		$api_url          = LINKBOSS_FETCH_REPORT_URL;
		$access_token     = get_transient( 'linkboss_access_token' );
		$linkboss_reports = get_transient( 'linkboss_reports' );

		if ( ! empty( $linkboss_reports ) ) {
			return;
		}

		if ( empty( $access_token ) ) {
			return;
		}

		$headers = array(
			'Content-Type'  => 'application/json',
			'Authorization' => "Bearer $access_token",
		);

		$arg = array(
			'headers' => $headers,
		);

		$response = wp_remote_get( $api_url, $arg );
		$res_body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( empty( $res_body ) ) {
			return;
		}

		set_transient( 'linkboss_reports', $res_body, 4 * HOUR_IN_SECONDS );

	}
}