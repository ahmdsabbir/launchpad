<?php
/**
 * Admin class
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description of Menu
 * 
 * @since 0.0.0
 */

class Admin {
	/**
	 * Construct
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$layouts = new Admin\Layouts();
		$this->dispatch_actions();

		new Admin\Menu( $layouts );
	}

	/**
	 * Dispatch Actions
	 *
	 * @since 1.0.0
	 */
	public function dispatch_actions() {
		new Classes\Auth();
		new Classes\Settings();
		new Classes\Render();

		$api_valid = get_option( 'linkboss_api_key', false );

		if ( $api_valid ) {
			new Classes\Posts();
			new Classes\Ajax_Sync();
		}
	}
}