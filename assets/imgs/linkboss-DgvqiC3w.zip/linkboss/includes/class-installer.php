<?php
/**
 * Installer class
 * 
 * @package LinkBoss
 * @since 0.0.5
 */

namespace LinkBoss;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Installer of Menu
 * 
 * @since 0.0.5
 */
class Installer {

	/**
	 * Runt the installer
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function run() {
		$this->add_version();
		/**
		 * Will be removed in future Delete Table
		 */
		// $this->delete_table();
		$this->create_tables();

		$licenseKey   = 'ABF7E20D-4744EBC3-1BA5B052-974D2511';
		$licenseEmail = get_bloginfo( 'admin_email' );

		update_option( "linkBoss_lic_key", $licenseKey ) || add_option( "linkBoss_lic_key", $licenseKey );
		update_option( "linkBoss_lic_email", $licenseEmail ) || add_option( "linkBoss_lic_email", $licenseEmail );
	}

	public function delete_table() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'linkboss_sync_batch';

		// Check if the table exists
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) == $table_name ) {
			// Table exists, so delete it
			$wpdb->query( "DROP TABLE IF EXISTS $table_name" );
		}

	}

	/**
	 * Add plugin version to database
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function add_version() {
		$installed = get_option( 'linkboss_installed' );

		if ( ! $installed ) {
			update_option( 'linkboss_installed', time() );
		}

		update_option( 'linkboss_version', LINKBOSS_VERSION );
	}

	/**
	 * Create nessary database tables
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		/**
		 * Create Sync Batch Table
		 *
		 * @since 0.0.5
		 */
		// $schema_sync_batch = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}linkboss_sync_batch`(
		// 	`id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		// 	`post_id` BIGINT(20) UNSIGNED NOT NULL UNIQUE,
		// 	`content_size` INT(11) NULL DEFAULT NULL,
		// 	`post_type` VARCHAR(255) DEFAULT 'post' COMMENT 'post, page, attachment',
		// 	`post_status` VARCHAR(255) DEFAULT 'post' COMMENT 'post, page, attachment',
		// 	`status` VARCHAR(1) NULL DEFAULT NULL COMMENT 'bool(1=Sent, NULL=Not Sent)',
		// 	`page_builder` VARCHAR(255) DEFAULT NULL COMMENT 'Elementor, Gutenberg etc',
		// 	`others_data` LONGTEXT DEFAULT NULL COMMENT 'Other Data',
		// 	`created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data DB Created Server Time',
		// 	`sync_at` TIMESTAMP NULL COMMENT 'Last Activity of APPS'
		// );) $charset_collate";

		$schema_sync_batch = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}linkboss_sync_batch (
			id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
			post_id BIGINT(20) UNSIGNED NOT NULL UNIQUE,
			content_size INT(11) NULL DEFAULT NULL,
			post_type VARCHAR(50) DEFAULT 'post' COMMENT 'post, page, attachment',
			post_status VARCHAR(50) DEFAULT 'post' COMMENT 'post, page, attachment',
			status TINYINT(1) NULL DEFAULT NULL COMMENT '1=Sent, NULL=Not Sent',
			page_builder VARCHAR(255) DEFAULT NULL COMMENT 'Elementor, Gutenberg etc',
			others_data LONGTEXT DEFAULT NULL COMMENT 'Other Data',
			created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data DB Created Server Time',
			sync_at TIMESTAMP NULL COMMENT 'Last Activity of APPS',
			INDEX idx_post_id (post_id)
		) $charset_collate";

		if ( ! function_exists( 'dbDelta' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}

		$result = dbDelta( $schema_sync_batch );

		if ( $result === false ) {
			set_transient( 'linkboss_sync_batch_table_error', 'Failed to create sync batch table', 7 * DAY_IN_SECONDS );
		}
	}
}