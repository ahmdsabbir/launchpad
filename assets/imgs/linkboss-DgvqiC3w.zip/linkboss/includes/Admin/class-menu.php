<?php
/**
 * Menu class
 * 
 * @package LinkBoss\Admin
 * @since 0.0.0
 */

namespace LinkBoss\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description of Menu
 * 
 * @since 0.0.0
 */
class Menu {
	/**
	 * Layouts
	 * 
	 * @since 0.0.0
	 */
	public $layouts;

	/**
	 * Constructor
	 * 
	 * @param object $layouts Layouts.
	 * @return void
	 * @since 0.0.0
	 */
	public function __construct( $layouts ) {
		$this->layouts = $layouts;
		add_action( 'admin_menu', [ $this, 'admin_menu' ] );
	}

	/**
	 * Admin menu
	 * 
	 * @since 0.0.0
	 */
	public function admin_menu() {
		$parent_slug = 'linkboss';
		$capability  = 'manage_options';

		add_menu_page(
			esc_html__( 'LinkBoss', 'linkboss' ),
			esc_html__( 'LinkBoss', 'linkboss' ),
			$capability,
			$parent_slug,
			array( $this->layouts, 'plugin_layout' ),
			'dashicons-admin-links',
			99
		);

		add_submenu_page(
			$parent_slug,
			esc_html__( 'Settings', 'linkboss' ),
			esc_html__( 'Settings', 'linkboss' ),
			$capability,
			$parent_slug . '-settings',
			array( $this->layouts, 'plugin_settings' )
		);
		add_submenu_page(
			$parent_slug,
			esc_html__( 'Upgrade', 'linkboss' ),
			esc_html__( 'Upgrade', 'linkboss' ),
			$capability,
			$parent_slug . '&linkboss_pro',
			array( $this->layouts, 'plugin_report' )
		);
	}
}