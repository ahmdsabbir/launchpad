<?php
$linkboss_api_key = get_option( 'linkboss_api_key' );

// hide half of the api key by replacing it with asterisks
$linkboss_api_key = substr_replace( $linkboss_api_key, '********', 8, 8 );
//7b31a09e719d383c739f6bda54b274ef





?>
<div class="flex items-center justify-center p-12">
	<!-- Author: FormBold Team -->
	<!-- Learn More: https://formbold.com -->
	<div class="mx-auto w-full max-w-[550px] bg-white">
		<form class="py-6 px-9" action="https://formbold.com/s/FORM_ID" method="POST">
			<h2>Welcome Page</h2>
			<!-- <div class="mb-5">
				<label class="mb-5 block text-xl font-semibold text-[#07074D]">
					LINKBOSS API KEY
				</label>
				<input type="api" name="api" id="api" value="<?php //esc_html_e( $linkboss_api_key ); ?>"
					class="w-full rounded-md border border-[#e0e0e0] bg-white py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md" />
			</div> -->
			<!-- <div>
				<button
					class="hover:shadow-form w-full rounded-md bg-[#6A64F1] py-3 px-8 text-center text-base font-semibold text-white outline-none">
					SYNC
				</button>
			</div>
			<div class="mb-6 pt-4">
				<div class="rounded-md bg-[#F5F7FB] py-4 px-8">
					<div class="flex items-center justify-between">
						<span class="truncate pr-3 text-base font-medium text-[#07074D]">
							SYNCING
						</span>
					</div>
					<div class="relative mt-5 h-[6px] w-full rounded-lg bg-[#E2E5EF]">
						<div class="absolute left-0 right-0 h-full w-[50%] rounded-lg bg-[#6A64F1]"></div>
					</div>
				</div>
			</div> -->
		</form>
	</div>
</div>