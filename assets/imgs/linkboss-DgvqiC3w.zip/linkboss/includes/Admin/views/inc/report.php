<?php
$api_valid    = get_option( 'linkboss_api_key', false );
$reports_data = get_transient( 'linkboss_reports' );

$updates_posts = isset( $reports_data['recents'] ) ? json_decode( wp_json_encode( $reports_data['recents'] ), true ) : null;

// echo '<pre>';
// print_r( $reports_data );
// echo '</pre>';


?>
<div class="mt-6">
	<button id="lb-sync-report-manually" type="button"
		class="text-white bg-[#3b5998] hover:bg-[#3b5998]/90 focus:ring-4 focus:outline-none focus:ring-[#3b5998]/50 font-medium rounded-lg text-sm py-4 px-5 text-center inline-flex items-center dark:focus:ring-[#3b5998]/55 mr-2 mb-2 gap-1">
		<svg class="w-4 h-4 mr-2" fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
			<path
				d="M105.1 202.6c7.7-21.8 20.2-42.3 37.8-59.8c62.5-62.5 163.8-62.5 226.3 0L386.3 160H336c-17.7 0-32 14.3-32 32s14.3 32 32 32H463.5c0 0 0 0 0 0h.4c17.7 0 32-14.3 32-32V64c0-17.7-14.3-32-32-32s-32 14.3-32 32v51.2L414.4 97.6c-87.5-87.5-229.3-87.5-316.8 0C73.2 122 55.6 150.7 44.8 181.4c-5.9 16.7 2.9 34.9 19.5 40.8s34.9-2.9 40.8-19.5zM39 289.3c-5 1.5-9.8 4.2-13.7 8.2c-4 4-6.7 8.8-8.1 14c-.3 1.2-.6 2.5-.8 3.8c-.3 1.7-.4 3.4-.4 5.1V448c0 17.7 14.3 32 32 32s32-14.3 32-32V396.9l17.6 17.5 0 0c87.5 87.4 229.3 87.4 316.7 0c24.4-24.4 42.1-53.1 52.9-83.7c5.9-16.7-2.9-34.9-19.5-40.8s-34.9 2.9-40.8 19.5c-7.7 21.8-20.2 42.3-37.8 59.8c-62.5 62.5-163.8 62.5-226.3 0l-.1-.1L125.6 352H176c17.7 0 32-14.3 32-32s-14.3-32-32-32H48.4c-1.6 0-3.2 .1-4.8 .3s-3.1 .5-4.6 1z" />
		</svg>
		<span class="lb-text">
			<?php esc_html_e( 'Sync Data', 'linkboss' ); ?>
		</span>
		</span>
		<span class="lb-progress-perc"></span>
	</button>
</div>
<div class="lb-reposts-one-grid mt-6">

	<?php

	$total_links = ( isset( $reports_data['internal'] ) ? $reports_data['internal'] : 0 ) + ( isset( $reports_data['external'] ) ? $reports_data['external'] : 0 );

	$info_data = array(
		array(
			'name'  => 'Total URLS',
			'value' => $total_links,
			'svg'   => '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
				stroke="currentColor" class="h-10 w-10 text-gray-500 dark:text-gray-400 mb-3">
				<path stroke-linecap="round" stroke-linejoin="round"
					d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
			</svg>',
		),
		array(
			'name'  => 'ORPHAN PAGES',
			'value' => isset( $reports_data['orphans'] ) ? $reports_data['orphans'] : 0,
			'svg'   => '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
				stroke="currentColor" class="h-10 w-10 text-gray-500 dark:text-gray-400 mb-3">
				<path stroke-linecap="round" stroke-linejoin="round"
					d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.257c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184" />
			</svg>',
		),
		array(
			'name'  => 'INTERNAL LINKS',
			'value' => isset( $reports_data['internal'] ) ? $reports_data['internal'] : 0,
			'svg'   => '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
				stroke="currentColor" class="h-10 w-10 text-gray-500 dark:text-gray-400 mb-3">
				<path stroke-linecap="round" stroke-linejoin="round"
					d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244" />
			</svg>',
		),
		array(
			'name'  => 'EXTERNAL LINKS',
			'value' => isset( $reports_data['external'] ) ? $reports_data['external'] : 0,
			'svg'   => '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
				stroke="currentColor" class="h-10 w-10 text-gray-500 dark:text-gray-400 mb-3">
				<path stroke-linecap="round" stroke-linejoin="round"
					d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" />
			</svg>',
		),
	);
	?>
	<?php foreach ( $info_data as $data ) : ?>
		<div
			class="flex justify-between p-9 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
			<div>
				<a href="javascript:void(0);">
					<h3 class="mb-3 mt-0 text-3xl font-semibold tracking-tight text-gray-900 dark:text-white">
						<?php echo esc_html( $data['value'] ); ?>
					</h3>
				</a>
				<h5 class="mb-0 mt-0 text-sm font-semibold tracking-tight text-gray-500 dark:text-white uppercase">
					<?php echo esc_html( $data['name'] ); ?>
				</h5>
			</div>
			<div>
				<?php echo $data['svg']; ?>
			</div>
		</div>
	<?php endforeach; ?>
</div>

<div class="mt-10">
	<div class="relative overflow-x-auto shadow-md sm:rounded-lg">
		<table id="lb-posts-table"
			class="lb-posts-table display w-full text-sm text-left text-gray-500 dark:text-gray-400">
			<caption
				class="p-5 text-lg font-semibold text-left text-gray-900 bg-white dark:text-white dark:bg-gray-800">
				<?php esc_html_e( 'Latest Updated Posts & Pages.', 'linkboss' ); ?>
				<p class="mt-1 text-sm font-normal text-gray-500 dark:text-gray-400">
					<?php esc_html_e( 'The following posts and pages have been updated recently.', 'linkboss' ); ?>
				</p>
			</caption>
			<thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
				<tr>
					<th scope="col" class="px-6 py-3">
						<?php esc_html_e( 'Pages & Posts', 'linkboss' ); ?>
					</th>
					<th scope="col" class="px-6 py-3">
						<?php esc_html_e( 'Updated At', 'linkboss' ); ?>
					</th>
				</tr>
			</thead>
			<tbody>
				<?php
				if ( $api_valid ) {
					\LinkBoss\Classes\Render::latest_updated_posts( $updates_posts );
				}
				?>
			</tbody>
		</table>
	</div>

</div>