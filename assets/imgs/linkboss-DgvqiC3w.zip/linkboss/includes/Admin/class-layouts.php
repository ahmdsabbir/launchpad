<?php
/**
 * Layouts Handler
 * 
 * @package LinkBoss\Admin
 * @since 0.0.0
 */

namespace LinkBoss\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description of Menu
 * 
 * @since 0.0.0
 */
class Layouts {

	/**
	 * Plugin Layouts
	 * 
	 * @return void
	 * @since 0.0.0
	 */
	public function plugin_layout() {
		$template = __DIR__ . '/views/layouts.php';

		if ( file_exists( $template ) ) {
			include $template;
		}
	}

	/**
	 * Layouts
	 * 
	 * @return void
	 * @since 0.0.0
	 */
	public function plugin_settings() {
		$template = __DIR__ . '/views/settings.php';

		if ( file_exists( $template ) ) {
			include $template;
		}
	}
}
