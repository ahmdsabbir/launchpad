<?php
/**
 * Cron Handler
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use LinkBoss\Classes\Auth;
use LinkBoss\Classes\Updates;
use LinkBoss\Classes\Update_Posts;
use LinkBoss\Classes\Posts;
use LinkBoss\Classes\Init;

/**
 * Description of Cron
 * 
 * @since 0.0.0
 */
class Cron {
	private static $instance = null;

	/**
	 * Get Instance
	 * 
	 * @since 0.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Construct
	 * 
	 * @since 0.0.0
	 */
	public function __construct() {

		register_deactivation_hook( LINKBOSS_PLUGIN__FILE__, array( $this, 'deactivate' ) );

		/**
		 * Get Access Token
		 * 
		 * @since 0.0.5
		 */
		$this->create_cron_job( 'linkboss_access_token', 24 * HOUR_IN_SECONDS, 'get_access_token' );

		/**
		 * Fetch Posts & Update to WordPress
		 * 
		 * @since 0.0.5
		 */
		$this->create_cron_job( 'linkboss_fetch_and_update_posts', MINUTE_IN_SECONDS * 2, 'fetch_update_posts' );

		/**
		 * Sync Posts to LinkBoss
		 * 
		 * @since 0.0.6
		 */
		// $this->create_cron_job( 'linkboss_sync_posts', 30 * MINUTE_IN_SECONDS, 'sync_posts' );

		/**
		 * Remove rows from sync table when status 24 hours gone
		 * 
		 * @since 0.0.7
		 */
		// $this->create_cron_job( 'linkboss_remove_rows_from_sync_table', 24 * HOUR_IN_SECONDS, 'remove_rows_from_sync_table' );

		/**
		 * Batch Processing for Sync Posts
		 * 
		 * @since 2.0.5
		 */
		$this->create_cron_job( 'linkboss_ready_batch_for_process', 4 * HOUR_IN_SECONDS, 'ready_batch_for_process' );

		/**
		 * Insert Table IDs for Batch Sync
		 * 
		 * @since 0.1.0
		 */
		$this->create_cron_job( 'linkboss_init_table_ids_for_batch', 2 * HOUR_IN_SECONDS, 'init_table_ids_for_batch' );

		/**
		 * Sync Posts to LinkBoss on Post Update Manually
		 * 
		 * @since 0.1.0
		 */
		add_action( 'post_updated', array( $this, 'sync_posts_on_post_update' ), 20, 3 );

		/**
		 * Sync Posts to LinkBoss on Post Draft Manually
		 * 
		 * @since 0.1.0
		 */
		add_action( 'draft_post', array( $this, 'sync_posts_on_post_update' ), 20, 3 );

		/**
		 * Sync Posts to LinkBoss on Post Trash Manually
		 * 
		 * @since 0.1.0
		 */
		add_action( 'trash_post', array( $this, 'sync_posts_on_post_update' ), 20, 3 );

		/**
		 * Sync Posts to LinkBoss on Post Publish Manually
		 * 
		 * @since 0.1.0
		 */
		add_action( 'publish_post', array( $this, 'sync_posts_on_post_update' ), 20, 3 );
	}

	/**
	 * Create a custom cron job
	 * 
	 * @param string $hook The unique hook name for this job.
	 * @param int $interval The interval in seconds.
	 * @param string $callback The name of the callback method.
	 */
	public function create_cron_job( $hook, $interval, $callback ) {
		// Add a filter for custom schedule with the provided interval and $hook
		add_filter( 'cron_schedules', function ($schedules) use ($hook, $interval) {
			$schedules[ $hook ] = array(
				'interval' => $interval,
				'display'  => esc_html__( 'Custom Schedule', 'textdomain' )
			);
			return $schedules;
		}, 10, 1 );

		if ( ! wp_next_scheduled( $hook ) ) {
			wp_schedule_event( time(), $hook, $hook ); // Use $hook for the schedule name
		}

		add_action( $hook, array( $this, $callback ) );
	}

	/**
	 * Callback for your custom cron job
	 * Emergency Test Purpose
	 */
	public function custom_job_callback() {
		// Your custom job logic here for task 1
		$time = current_datetime();
		$time = $time->format( 'H-i-s' );
		$file = WP_CONTENT_DIR . '/test-' . $time . '.txt';

		if ( ! file_exists( $file ) ) {
			$fp = fopen( $file, 'w' );
			fwrite( $fp, 'test' );
			fclose( $fp );
		}
	}

	/**
	 * Add a custom schedule
	 * 
	 * @param array $schedules The existing schedules.
	 * @param int $interval The interval in seconds.
	 * @return array The modified schedules.
	 */
	public function add_custom_schedule( $schedules ) {
		// print_r( $schedules );
		$schedules['custom'] = array(
			'interval' => 60, // Change the interval as needed
			'display'  => __( 'Custom Schedule', 'textdomain' )
		);

		return $schedules;
	}

	/**
	 * Deactivate and unschedule all custom cron jobs
	 */
	public function deactivate() {
		$custom_jobs = array(
			'linkboss_access_token',
			'linkboss_fetch_and_update_posts',
			'linkboss_sync_posts_to_server',
		);

		foreach ( $custom_jobs as $hook ) {
			$timestamp = wp_next_scheduled( $hook );
			wp_unschedule_event( $timestamp, $hook );
		}
	}

	/**
	 * Sync Posts to LinkBoss on Post Update Manually
	 * 
	 * @since 0.0.6
	 */
	public static function sync_posts_on_post_update( $post_id ) {
		$updates_obj = new Updates();
		$updates_obj->data_sync_require( $post_id );

		Posts::sync_posts_by_cron_and_hook();
	}

	/**
	 * Get Access Token
	 * 
	 * @since 0.0.5
	 */
	public static function get_access_token() {
		Auth::get_access_token_by_refresh_token();
	}

	/**
	 * Fetch Posts & Update to WordPress
	 * 
	 * @since 0.0.5
	 */
	public static function fetch_update_posts() {
		Update_Posts::fetch_update_posts();
	}

	/**
	 * Sync Posts to LinkBoss
	 * 
	 * @since 0.0.5
	 */
	public static function sync_posts() {
		Posts::sync_posts_by_cron_and_hook();
	}

	/**
	 * Remove rows from sync table when status is D and sync_at time gone 3 days
	 * 
	 * @since 0.0.7
	 */
	public static function remove_rows_from_sync_table() {
		global $wpdb;

		$table = $wpdb->prefix . 'linkboss_sync_batch';
		$wpdb->query( "TRUNCATE TABLE $table" );

		// Calculate the date three days ago
		// $threeDaysAgo = date( 'Y-m-d H:i:s', strtotime( '-3 days' ) );

		// $wpdb->delete(
		// 	$wpdb->prefix . 'linkboss_sync_batch',
		// 	array(
		// 		'status'  => 'D',
		// 		'sync_at' => array(
		// 			'compare' => '<=',
		// 			'value'   => $threeDaysAgo,
		// 			'type'    => 'DATETIME',
		// 		),
		// 	)
		// );
	}

	/**
	 * Init Table IDs
	 * 
	 * @since 0.1.0
	 */
	public static function init_table_ids_for_batch() {
		Init::init_table_ids_for_batch( true );
	}

	/**
	 * Init Table IDs
	 * 
	 * @since 0.1.0
	 */
	public static function ready_batch_for_process() {
		Posts::cron_ready_batch_for_process();
	}

}

if ( class_exists( 'LinkBoss\Classes\Cron' ) ) {
	\LinkBoss\Classes\Cron::get_instance();
}