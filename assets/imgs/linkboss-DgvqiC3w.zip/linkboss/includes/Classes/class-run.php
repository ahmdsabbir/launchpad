<?php
/**
 * Run Handler
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description of Run
 * 
 * This class is for testing purpose only 
 * Request by @Prapon
 * 
 * @since 0.0.0
 */
class Run {

	private static $instance = null;

	/**
	 * Get Instance
	 * 
	 * @since 0.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Construct
	 * 
	 * @since 0.0.0
	 */
	public function __construct() {
		add_action( 'wp_ajax_lb_run', [ $this, 'lb_run' ] );
	}

	/**
	 * Run
	 * 
	 * @since 0.0.0
	 */
	public function lb_run() {
		echo wp_json_encode(
			array(
				'status' => 'success run',
			)
		);
		wp_die();
	}
}

if ( class_exists( 'LinkBoss\Classes\Run' ) ) {
	\LinkBoss\Classes\Run::get_instance();
}