<?php
/**
 * Init Handler
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description of Init
 * 
 * @since 0.0.0
 */
class Init {

	private static $instance = null;

	/**
	 * Get Instance
	 * 
	 * @since 0.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Construct
	 * 
	 * @since 0.0.0
	 */
	public function __construct() {
		add_action( 'wp_ajax_lb_sync_batch', [ $this, 'init_table_ids_for_batch' ] );

		// if ( isset( $_GET['page'] ) && $_GET['page'] == 'linkboss-settings' ) {
		// 	self::init_table_ids_for_batch( false );
		// }
	}

	/**
	 * Init Table IDs
	 */
	public static function init_table_ids_for_batch( $limit = false ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'linkboss_sync_batch';

		// $sql = "SELECT ID, post_type, post_content, post_status
		//     FROM {$wpdb->prefix}posts
		//     WHERE ID NOT IN (SELECT post_id FROM {$wpdb->prefix}linkboss_sync_batch)
		//     AND post_type IN ('post', 'page') AND post_status IN ('publish')";
		$sql = "SELECT p.ID, p.post_type, p.post_content, p.post_status
				FROM {$wpdb->prefix}posts p
				LEFT JOIN {$wpdb->prefix}linkboss_sync_batch l ON p.ID = l.post_id
				WHERE l.post_id IS NULL
				AND p.post_type IN ('post', 'page')
				AND p.post_status = 'publish' LIMIT 50";

		$posts = $wpdb->get_results( $sql, ARRAY_A );

		// Split the data into batches of 100
		$batches = array_chunk( $posts, 200 );

		$totalBatches = count( $batches );
		$currentBatch = 0;

		foreach ( $batches as $batch ) {
			// Create the SQL query for inserting
			$insertSql = "INSERT IGNORE INTO $table_name (post_id, post_type, post_status, content_size) VALUES ";

			// Use the array values to construct the query
			$values = [];

			foreach ( $batch as $post ) {
				$post_id      = $post['ID'];
				$post_content = $post['post_content'];
				$post_type    = $post['post_type'];
				$post_status  = $post['post_status'];
				$content_size = mb_strlen( $post_content, '8bit' ); // Calculate size in bytes

				// Escape and include the post_id, post_type, and content size in the query
				$values[] = "($post_id, '$post_type', '$post_status', $content_size)";
			}

			// Combine the values and execute the query
			$insertSql .= implode( ', ', $values );
			$wpdb->query( $insertSql );

			// Update progress
			$currentBatch++;
			$progress = ( $currentBatch / $totalBatches ) * 100;
			// set_transient( 'linkboss_sync_batch_progress', $progress, 60 ); // Store the progress for 60 seconds
		}
	}
	public static function __init_table_ids_for_batch( $limit = false ) {

		$posts = get_posts( array(
			'posts_per_page' => false === $limit ? -1 : 5,
			'fields'         => 'ids',
			'post_type'      => array( 'post', 'page' ),
			'post_status'    => 'publish',
		) );

		global $wpdb;
		$table_name = $wpdb->prefix . 'linkboss_sync_batch';

		// Split the data into batches of 100
		$batches = array_chunk( $posts, 100 );

		$totalBatches = count( $batches );
		$currentBatch = 0;

		foreach ( $batches as $batch ) {
			// Create the SQL query
			$sql = "INSERT IGNORE INTO $table_name (post_id, post_type, post_status, content_size) VALUES ";

			// Use the array values to construct the query
			$values = [];

			foreach ( $batch as $post_id ) {
				$post         = get_post( $post_id );
				$post_content = $post->post_content;
				$post_type    = $post->post_type;
				$post_status  = $post->post_status;
				$content_size = mb_strlen( $post_content, '8bit' ); // Calculate size in bytes

				// Escape and include the post_id, post_type, and content size in the query
				$values[] = "($post_id, '$post_type', '$post_status', $content_size)";
			}

			// Combine the values and execute the query
			$sql .= implode( ', ', $values );
			$wpdb->query( $sql );

			// Update progress
			$currentBatch++;
			$progress = ( $currentBatch / $totalBatches ) * 100;
			// set_transient( 'linkboss_sync_batch_progress', $progress, 60 ); // Store the progress for 60 seconds
		}
	}

}

if ( class_exists( 'LinkBoss\Classes\Init' ) ) {
	\LinkBoss\Classes\Init::get_instance();
}