<?php
/**
 * Posts Handler
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use LinkBoss\Classes\Auth;

/**
 * Description of Posts
 * 
 * @since 0.0.0
 */
class Posts {

	private static $msg_disabled = false;
	/**
	 * Construct
	 * 
	 * @since 0.0.0
	 */
	public function __construct() {
		// add_action( 'wp_ajax_linkboss_sync_posts_cron_socket', array( $this, 'sync_posts_by_cron_and_hook' ) );
	}

	public static function cron_ready_batch_for_process() {
		self::$msg_disabled = true;
		$posts              = new self();
		$posts->ready_batch_for_process();
	}

	/**
	 * Sync Posts by Cron & Hook
	 * Special Cron Job for Sync Posts to remove message
	 * 
	 * @since 0.1.0
	 */
	public static function sync_posts_by_cron_and_hook() {
		self::$msg_disabled = true;
		$posts              = new self();
		$batches            = $posts->ready_batch_for_process();
		$posts->send_batch_of_posts( $batches );
	}

	public function send_batch_of_posts( $batches ) {

		/**
		 * Validate Access Token
		 */
		$valid_tokens = self::valid_tokens();

		if ( true === $valid_tokens ) {
			$this->lb_send_posts( $batches );
		} else {
			if ( true !== self::$msg_disabled ) {
				echo wp_json_encode(
					array(
						'status' => 'error',
						'title'  => 'Error!',
						'msg'    => esc_html__( 'Please Try Again.', 'linkboss' ),
					)
				);
				wp_die();
			}
		}
	}

	/**
	 * Undocumented function
	 *
	 * @return array
	 */
	public function ready_batch_for_process() {
		// Set the maximum size threshold in bytes (512KB).
		$maxSizeThreshold = 1024 * 512;

		// Initialize an array to store batches of post_id values.
		$batches = array();

		// Initialize variables to keep track of the current batch.
		$currentBatch     = array();
		$currentBatchSize = 0;

		global $wpdb;
		$tableName = $wpdb->prefix . 'linkboss_sync_batch';

		// Query the database for post_id and content_size ordered by content_size.
		$query   = "SELECT post_id, content_size FROM $tableName WHERE status is NULL ORDER BY post_id ASC LIMIT 5";
		$results = $wpdb->get_results( $query );

		if ( ! $results ) {
			return [];
		}

		foreach ( $results as $row ) {
			$dataId      = $row->post_id;
			$contentSize = $row->content_size;

			// If adding this row to the current batch exceeds the threshold, start a new batch.
			if ( $currentBatchSize + $contentSize > $maxSizeThreshold ) {
				$batches[]        = $currentBatch;
				$currentBatch     = array();
				$currentBatchSize = 0;
			}

			// Add the post_id to the current batch.
			$currentBatch[]   = $dataId;
			$currentBatchSize += $contentSize;
		}

		// Add any remaining data to the last batch.
		if ( ! empty( $currentBatch ) ) {
			$batches[] = $currentBatch;
		}

		return $batches;
	}

	/**
	 * Send WordPress Posts as JSON
	 * 
	 * @since 0.0.0
	 */
	public static function lb_send_posts( $batches ) {
		// print_r( $batches );
		foreach ( $batches as $batch ) :

			/**
			 * $batch is an array of post_id
			 * Example: [ 3142, 3141, 3140 ]
			 */

			$posts = get_posts( [ 
				'numberposts' => -1,
				'post_type'   => array( 'post', 'page' ),
				'post_status' => array( 'publish', 'draft', 'trash' ),
				'post__in'    => $batch,
			] );

			$prepared_posts = array_map( function ($post) {
				return array(
					'_postId'    => $post->ID,
					'category'   => wp_json_encode( $post->post_category ),
					'title'      => $post->post_title,
					'content'    => $post->post_content,
					'postType'   => $post->post_type,
					'postStatus' => $post->post_status,
					'createdAt'  => $post->post_date,
					'updatedAt'  => $post->post_modified,
					'url'        => get_permalink( $post->ID ),
				);
			}, $posts );

			self::send_group( $prepared_posts, $batch, false );

		endforeach;

	}

	/**
	 * Send WordPress Posts as JSON
	 * 
	 * @since 0.0.0
	 */
	public static function send_group( $data, $batch, $last = false ) {
		$api_url      = ! $last ? LINKBOSS_POSTS_SYNC_URL : LINKBOSS_OPTIONS_URL;
		$access_token = get_transient( 'linkboss_access_token' );

		$headers = array(
			'Content-Type'  => 'application/json',
			'Authorization' => "Bearer $access_token",
		);

		$body = array(
			'posts' => ! $last ? $data : array(),
		);

		$arg = array(
			'headers' => $headers,
			'body'    => wp_json_encode( $body ),
			'method'  => 'POST',
		);

		$response = wp_remote_post( $api_url, $arg );
		$res_body = json_decode( wp_remote_retrieve_body( $response ) );

		$res_msg = isset( $res_body->message ) ? $res_body->message : esc_html__( 'Something went wrong!', 'linkboss' );

		$res_code = wp_remote_retrieve_response_code( $response );

		if ( $res_code !== 200 && $res_code !== 201 ) {
			set_transient( 'linkboss_sync_error', $response, 7 * DAY_IN_SECONDS );

			if ( true !== self::$msg_disabled ) {
				echo wp_json_encode(
					array(
						'status' => 'error',
						'title'  => 'Error!',
						'msg'    => esc_html__( $res_msg . '. Error Code-' . $res_code, 'linkboss' ),
					)
				);
				wp_die();
			}
		}

		/**
		 * Batch update
		 * Send Batch when the request response is 200 || 201
		 */
		if ( ( $res_code == 200 || $res_code == 201 ) && ! empty( $batch ) ) {
			self::batch_update( $batch );
		}

		if ( true !== self::$msg_disabled ) {
			echo wp_json_encode(
				array(
					'status' => 'success',
					'title'  => 'Success!',
					'msg'    => esc_html__( $res_msg, 'linkboss' ),
				)
			);
		}
		if ( $last ) {
			ob_start();
			if ( ( $res_code == 200 || $res_code == 201 ) && empty( $batch ) ) {
			}

			if ( true !== self::$msg_disabled ) {
				wp_json_encode(
					array(
						'status' => 'success',
						'title'  => 'Success!',
						'msg'    => esc_html__( $res_msg, 'linkboss' ),
					)
				);

				$buffer = ob_get_clean();
				echo $buffer;
				wp_die();
			}
		}
	}

	public static function batch_update( $batch_ids ) {
		global $wpdb;

		$post_ids_list = implode( ',', $batch_ids );
		// echo '==========';
		// print_r( $batch_ids );
		// echo '==========';

		// Get the current date and time in MySQL datetime format
		$current_time = current_time( 'mysql' );

		// SQL query to update the status and sync_at in the custom table
		$query = $wpdb->prepare( "UPDATE {$wpdb->prefix}linkboss_sync_batch 
                             SET status = 1, sync_at = %s 
                             WHERE post_id IN ({$post_ids_list})", $current_time );

		// Execute the query
		$wpdb->query( $query );
	}

	/**
	 * Validate Access & Refresh Token on First Request
	 * If not valid then get new tokens programmatically
	 */
	public static function valid_tokens() {
		$api_url      = LINKBOSS_POSTS_SYNC_URL;
		$access_token = get_transient( 'linkboss_access_token' );

		$headers = array(
			'Content-Type'  => 'application/json',
			'Authorization' => "Bearer $access_token",
		);

		$body = array(
			'posts' => array(),
		);

		$arg = array(
			'headers' => $headers,
			'body'    => wp_json_encode( $body ),
			'method'  => 'POST',
		);

		$response = wp_remote_post( $api_url, $arg );
		$res_code = wp_remote_retrieve_response_code( $response );

		if ( $res_code === 401 ) {
			return Auth::get_tokens_by_auth_code();
		}

		return true;
	}

}