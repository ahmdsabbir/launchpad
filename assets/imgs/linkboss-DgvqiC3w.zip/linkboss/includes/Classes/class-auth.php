<?php
/**
 * Auth Handler
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description of Auth
 * 
 * @since 0.0.0
 */
class Auth {

	/**
	 * Construct
	 * 
	 * @since 0.0.0
	 */
	public function __construct() {
		add_action( 'wp_ajax_lb_auth_check', [ $this, 'lb_auth_check' ] );
	}

	/**
	 * Check
	 * 
	 * @since 0.0.0
	 */
	public function lb_auth_check() {
		$api_key = sanitize_text_field( $_POST['api_key'] );

		$api_url = LINKBOSS_AUTH_URL;

		$headers = array(
			'Content-Type' => 'application/json',
			'method'       => 'POST',
		);

		$body = array(
			'client'  => get_site_url(),
			'api_key' => $api_key,
		);

		$arg = array(
			'headers' => $headers,
			'body'    => json_encode( $body ),
			// 'method' can be omitted since you're using wp_remote_post()
			'method'  => 'POST',
		);

		$response = wp_remote_post( $api_url, $arg );
		$res_body = json_decode( wp_remote_retrieve_body( $response ) );

		if ( wp_remote_retrieve_response_code( $response ) !== 200 ) {
			$msg = isset( $res_body->message ) ? $res_body->message : '';
			echo wp_json_encode(
				array(
					'status' => 'error',
					'title'  => 'Error!',
					'msg'    => esc_html__( $msg . '. Error Code - ' . wp_remote_retrieve_response_code( $response ), 'linkboss' ),
				)
			);
			set_transient( 'linkboss_auth_error', $response, 7 * DAY_IN_SECONDS );
			wp_die();
		}

		if ( isset( $res_body->access ) && isset( $res_body->refresh ) ) {
			set_transient( 'linkboss_access_token', $res_body->access, 24 * HOUR_IN_SECONDS );
			set_transient( 'linkboss_refresh_token', $res_body->refresh, 15 * DAY_IN_SECONDS );
		}

		echo wp_json_encode(
			array(
				'status' => 'success',
				'title'  => 'Success!',
				'msg'    => esc_html__( $res_body->message, 'linkboss' ),
			)
		);

		delete_transient( 'linkboss_auth_error' );

		wp_die();
	}

	/**
	 * Get Access Token by Refresh Token
	 * 
	 * PATCH Request
	 * @since 0.0.5
	 */
	public static function get_access_token_by_refresh_token() {
		$api_url       = LINKBOSS_AUTH_URL;
		$refresh_token = get_transient( 'linkboss_refresh_token' );

		$headers = array(
			'Content-Type'  => 'application/json',
			'Authorization' => "Bearer $refresh_token",
			'method'        => 'PATCH',
		);

		$arg = array(
			'headers' => $headers,
			'method'  => 'PATCH',
		);

		$response = wp_remote_post( $api_url, $arg );
		$res_body = json_decode( wp_remote_retrieve_body( $response ) );

		$res_msg = isset( $res_body->message ) ? $res_body->message : esc_html__( 'Something went wrong on Auth!', 'linkboss' );

		if ( wp_remote_retrieve_response_code( $response ) !== 200 ) {
			echo wp_json_encode(
				array(
					'status' => 'error',
					'title'  => 'Error!',
					'msg'    => esc_html__( $res_msg . '. Error Code - ' . wp_remote_retrieve_response_code( $response ), 'linkboss' ),
				)
			);
			wp_die();
		}

		if ( isset( $res_body->access_token ) ) {
			set_transient( 'linkboss_access_token', $res_body->access_token, 24 * HOUR_IN_SECONDS );
		}

		echo wp_json_encode(
			array(
				'status' => 'success',
				'title'  => 'Success!',
				'msg'    => esc_html__( $res_body->message, 'linkboss' ),
			)
		);
		wp_die();
	}

	/**
	 * Get Access Token & Refresh Token by Auth Code
	 * 
	 * @version 0.0.9
	 */
	public static function get_tokens_by_auth_code() {
		$api_key = get_option( 'linkboss_api_key', false );

		$api_url = LINKBOSS_AUTH_URL;

		$headers = array(
			'Content-Type' => 'application/json',
			'method'       => 'POST',
		);

		$body = array(
			'client'  => get_site_url(),
			'api_key' => $api_key,
		);

		$arg = array(
			'headers' => $headers,
			'body'    => json_encode( $body ),
			'method'  => 'POST',
		);

		$response = wp_remote_post( $api_url, $arg );
		$res_body = json_decode( wp_remote_retrieve_body( $response ) );

		$res_code = wp_remote_retrieve_response_code( $response );

		if ( isset( $res_body->access ) && isset( $res_body->refresh ) && $res_code == 200 ) {
			set_transient( 'linkboss_access_token', $res_body->access, 24 * HOUR_IN_SECONDS );
			set_transient( 'linkboss_refresh_token', $res_body->refresh, 15 * DAY_IN_SECONDS );
			return true;
		}

		return false;
	}


}