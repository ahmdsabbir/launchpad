<?php
/**
 * Fetch Handler
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use LinkBoss\Traits\Global_Functions;

/**
 * Description of Fetch
 * 
 * @since 0.0.0
 */
class Fetch {

	use Global_Functions;

	private static $instance = null;

	/**
	 * Get Instance
	 * 
	 * @since 0.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Construct
	 * 
	 * @since 0.0.0
	 */
	public function __construct() {
		if ( isset( $_GET['page'] ) && $_GET['page'] == 'linkboss' ) {
			add_action( 'init', array( $this, 'fetch_reports' ) );
		}
		add_action( 'wp_ajax_linkboss_sync_reports_manually', array( $this, 'fetch_reports_manually' ) );
	}

	public function fetch_reports_manually() {
		delete_transient( 'linkboss_reports' );
		echo wp_json_encode( array(
			'status' => 'success',
			'msg'    => 'Reports Fetched Successfully',
		), true );
		wp_die();
	}
}

if ( class_exists( 'LinkBoss\Classes\Fetch' ) ) {
	\LinkBoss\Classes\Fetch::get_instance();
}