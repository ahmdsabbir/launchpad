<?php
/**
 * Updates Handler
 * Update or Send data to Sync Batch Table
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use LinkBoss\Traits\Global_Functions;

/**
 * Description of Updates
 * 
 * @since 0.0.0
 */
class Updates {

	use Global_Functions;
	private static $instance = null;

	/**
	 * Construct
	 * 
	 * @since 0.0.0
	 */
	public function __construct() {
		// add_action( 'save_post', array( $this, 'data_sync_require' ) );
		// add_action( 'post_updated', array( $this, 'data_sync_require' ) );
		// if post is deleted or trashed
		add_action( 'delete_post', array( $this, 'delete_sync_require' ) );
	}

	/**
	 * Delete Sync Request
	 * 
	 * @since 0.0.6
	 */
	public function delete_sync_require( $post_id ) {
		if ( ! $post_id ) {
			return;
		}

		// var_dump( $post_id );

		// get post type
		$post_type = get_post_type( $post_id );
		// get post status
		$post_status = get_post_status( $post_id );

		/**
		 * Mark as Delete
		 */
		self::update_sync_batch_table( $post_id, $post_type, $post_status, 'D' );
	}

	/**
	 * Send WordPress Posts as JSON
	 * 
	 * @since 0.0.0
	 */
	public function data_sync_require( $post_id ) {

		if ( ! $post_id ) {
			return;
		}

		/**
		 * Get post type
		 */
		$post_type   = get_post_type( $post_id );
		$post_status = get_post_status( $post_id );

		self::update_sync_batch_table( $post_id, $post_type, $post_status );
	}

	/**
	 * Update or Send data to Sync Batch Table
	 * 
	 * @since 0.0.5
	 */
	public static function update_sync_batch_table( $post_id, $post_type = 'post', $post_status = null, $status = null ) {
		global $wpdb;

		// Check if the post_id already exists in the table
		$query  = $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}linkboss_sync_batch WHERE post_id = %d", $post_id );
		$result = $wpdb->get_row( $query );

		if ( $result ) {
			// If the post_id exists, update the status to NULL
			$wpdb->update(
				$wpdb->prefix . 'linkboss_sync_batch',
				array(
					'post_status' => $post_status,
					'status'      => $status // Set status to NULL
				),
				array( 'post_id' => $post_id ),
				array( '%s', '%s' ), // Data type for 'status' field
				array( '%d' ) // Data type for 'post_id' field
			);
		} else {
			// If the post_id doesn't exist, insert a new row
			$wpdb->insert(
				$wpdb->prefix . 'linkboss_sync_batch',
				array(
					'post_id'     => $post_id,
					'post_type'   => $post_type,
					'post_status' => $post_status,
					'status'      => $status // Set status to NULL
				),
				array( '%d', '%s', '%s' ) // Data types for each field
			);
		}
	}

	/**
	 * Get Instance
	 * 
	 * @since 0.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

if ( class_exists( 'LinkBoss\Classes\Updates' ) ) {
	\LinkBoss\Classes\Updates::get_instance();
}