<?php
/**
 * Ajax Sync Class
 * 
 * @package LinkBoss
 * @since 2.0.3
 */

namespace LinkBoss\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use LinkBoss\Classes\Auth;

/**
 * Ajax Sync Class
 * 
 * @since 2.0.3
 */
class Ajax_Sync {

	public static $force_data = false;
	/**
	 * Class constructor
	 * 
	 * @since 2.0.3
	 */
	public function __construct() {
		add_action( 'wp_ajax_linkboss_get_batch_process', array( $this, 'get_batch_process' ) );
		add_action( 'wp_ajax_linkboss_prepare_batch_data', array( $this, 'prepare_batch_for_sync' ) );
		add_action( 'wp_ajax_linkboss_category_sync_process', array( $this, 'ready_wp_categories_for_sync' ) );
	}

	/**
	 * Create Batches for Sync
	 *
	 * @return array
	 */
	public function ready_batch_for_process() {
		// Set the maximum size threshold in bytes (512KB).
		$maxSizeThreshold = 1024 * 512;

		// Initialize an array to store batches of post_id values.
		$batches = array();

		// Initialize variables to keep track of the current batch.
		$currentBatch     = array();
		$currentBatchSize = 0;

		global $wpdb;
		$tableName = $wpdb->prefix . 'linkboss_sync_batch';

		// Query the database for post_id and content_size ordered by content_size.
		$query   = "SELECT post_id, content_size FROM $tableName WHERE status is NULL ORDER BY post_id ASC";
		$results = $wpdb->get_results( $query );

		if ( ! $results ) {
			return [];
		}

		foreach ( $results as $row ) {
			$dataId      = $row->post_id;
			$contentSize = $row->content_size;

			// If adding this row to the current batch exceeds the threshold, start a new batch.
			if ( $currentBatchSize + $contentSize > $maxSizeThreshold ) {
				$batches[]        = $currentBatch;
				$currentBatch     = array();
				$currentBatchSize = 0;
			}

			// Add the post_id to the current batch.
			$currentBatch[]   = $dataId;
			$currentBatchSize += $contentSize;
		}

		// Add any remaining data to the last batch.
		if ( ! empty( $currentBatch ) ) {
			$batches[] = $currentBatch;
		}

		return $batches;
	}

	/**
	 * Call Batch Process for Sync
	 */
	public function get_batch_process() {
		$batches = $this->ready_batch_for_process();

		$response = array(
			'status'  => 'success',
			'batches' => $batches,
		);

		update_option( 'linkboss_sync_batch', $batches );

		echo wp_json_encode( $response, true );
		wp_die();
	}

	public function prepare_batch_for_sync() {

		/**
		 * Data Idea
		 * $batches = [ [ 1, 2, 3, 4 ], [ 5, 6, 7, 8 ], [ 9, 10, 11, 12 ] ];
		 * $batches = [ [ 5, 6, 7, 8 ], [ 9, 10, 11, 12 ] ];
		 * $batches    = [ [ 9, 10, 11, 12 ] ];
		 */
		$batches = get_option( 'linkboss_sync_batch', [] );

		$sent_batch = isset( $batches[0] ) ? $batches[0] : [];
		$next_batch = array_slice( $batches, 1 );

		if ( isset( $_POST['forceData'] ) && 'yes' === $_POST['forceData'] ) {
			self::$force_data = true;
		}

		// echo '<pre>';
		// var_dump( $_POST['forceData'] );
		// echo '=============';
		// echo count( $batches );
		// print_r( $batches );
		// print_r( $sent_batch );
		// echo '</pre>';

		$this->ready_wp_posts_for_sync( $sent_batch );

		$response = array(
			'status'       => 'success',
			'sent_batch'   => $sent_batch,
			'next_batches' => count( $next_batch ) > 0 ? $next_batch : false,
			'batch_length' => count( $next_batch ),
			'has_batch'    => count( $next_batch ) > 0 ? 'yes' : false,
		);

		update_option( 'linkboss_sync_batch', $next_batch );

		echo wp_json_encode( $response, true );
		wp_die();
	}

	/**
	 * Ready WordPress Posts as JSON
	 * Ready posts by Batch
	 * 
	 * @since 2.0.3
	 */
	public function ready_wp_posts_for_sync( $batch ) {
		/**
		 * $batch is an array of post_id
		 * Example: [ 3142, 3141, 3140 ]
		 */

		$posts = get_posts( [ 
			'numberposts' => -1,
			'post_type'   => array( 'post', 'page' ),
			'post_status' => array( 'publish' ),
			'post__in'    => $batch,
		] );

		$prepared_posts = array_map( function ($post) {
			return array(
				'_postId'    => $post->ID,
				'category'   => wp_json_encode( $post->post_category ),
				'title'      => $post->post_title,
				'content'    => $post->post_content,
				'postType'   => $post->post_type,
				'postStatus' => $post->post_status,
				'createdAt'  => $post->post_date,
				'updatedAt'  => $post->post_modified,
				'url'        => get_permalink( $post->ID ),
			);
		}, $posts );

		if ( count( $prepared_posts ) <= 0 ) {
			return array(
				'status' => 200,
				'title'  => 'Success',
				'msg'    => esc_html__( 'Posts are up to date.', 'linkboss' ),
			);
		}

		self::send_group( $prepared_posts, $batch, false );

	}

	/**
	 * Send Categories as JSON on last batch
	 * 
	 * @since 2.0.3
	 */
	public function ready_wp_categories_for_sync() {

		$categories = get_categories( array(
			'orderby' => 'name',
			'order'   => 'ASC',
		) );

		$categories_data = array_map( function ($category) {
			return array(
				'categoryId' => $category->term_id,
				'name'       => $category->name,
				'slug'       => $category->slug,
			);
		}, $categories );

		$response = $this->send_group( $categories_data, '', true );

		if ( 200 === $response['status'] ) {
			echo wp_json_encode( array(
				'status' => 'success',
			), true );
		} else {
			echo wp_json_encode( array(
				'status' => 'error',
			), true );
		}
		wp_die();
	}

	/**
	 * Send WordPress Posts as JSON
	 * 
	 * @since 2.0.3
	 */
	public static function send_group( $data, $batch, $category = false ) {
		$api_url      = ! $category ? LINKBOSS_POSTS_SYNC_URL : LINKBOSS_OPTIONS_URL;
		$access_token = get_transient( 'linkboss_access_token' );

		$headers = array(
			'Content-Type'  => 'application/json',
			'Authorization' => "Bearer $access_token",
		);

		$body = array(
			'posts' => ! $category ? $data : array(),
		);

		if ( $category ) {
			$body = array(
				'categories' => $data,
			);
		}

		if ( true === self::$force_data ) {
			$body['force'] = true;
		}

		$arg = array(
			'headers' => $headers,
			'body'    => wp_json_encode( $body ),
			'method'  => 'POST',
		);

		$response = wp_remote_post( $api_url, $arg );
		$res_body = json_decode( wp_remote_retrieve_body( $response ) );

		$res_msg = isset( $res_body->message ) ? $res_body->message : esc_html__( 'Something went wrong!', 'linkboss' );

		$res_code = wp_remote_retrieve_response_code( $response );

		if ( $res_code !== 200 && $res_code !== 201 ) {
			return array(
				'status' => $res_code,
				'title'  => 'Error!',
				'msg'    => esc_html__( $res_msg . '. Error Code-' . $res_code, 'linkboss' ),
			);
		}

		/**
		 * Batch update
		 * Send Batch when the request response is 200 || 201
		 */
		if ( ( $res_code == 200 || $res_code == 201 ) && ! empty( $batch ) ) {
			self::batch_update( $batch );
		}

		return array(
			'status' => 200,
			'title'  => 'Success!',
			'msg'    => esc_html__( $res_msg, 'linkboss' ),
		);
	}

	public static function batch_update( $batch_ids ) {
		global $wpdb;

		$post_ids_list = implode( ',', $batch_ids );
		$current_time  = current_time( 'mysql' );

		$query = $wpdb->prepare( "UPDATE {$wpdb->prefix}linkboss_sync_batch SET status = 1, sync_at = %s WHERE post_id IN ({$post_ids_list})", $current_time );

		$wpdb->query( $query );
	}

}