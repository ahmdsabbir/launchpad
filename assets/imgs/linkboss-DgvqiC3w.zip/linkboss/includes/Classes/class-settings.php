<?php
/**
 * Settings Handler
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description of Settings
 * 
 * @since 0.0.0
 */
class Settings {

	/**
	 * Construct
	 * 
	 * @since 0.0.0
	 */
	public function __construct() {
		add_action( 'wp_ajax_linkboss_save_settings', array( $this, 'save_settings' ) );
		add_action( 'wp_ajax_linkboss_reset_sync_batch', array( $this, 'reset_sync_batch' ) );
	}

	/**
	 * Register settings
	 * 
	 * @since 0.0.0
	 */
	public function save_settings() {

		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'linkboss_nonce' ) ) {
			echo wp_json_encode(
				array(
					'status' => 'error',
					'title'  => 'Error!',
					'msg'    => esc_html__( 'Failed to insert data. Please refresh your browser. If that doesn\'t work, please contact support team.', 'linkboss' ),
				)
			);
			wp_die();
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$api_key = sanitize_text_field( $_POST['linkboss_api_key'] );
		update_option( 'linkboss_api_key', $api_key );
		set_transient( 'linkboss_progress', 0, 2 * HOUR_IN_SECONDS );

		echo wp_json_encode(
			array(
				'status' => 'success',
				'title'  => 'Success!',
				'msg'    => esc_html__( 'Congrats, the API Key was saved successfully.', 'linkboss' ),
			)
		);
		wp_die();
	}

	/**
	 * Reset Sync Batch
	 * 
	 * @since 0.0.5
	 */
	public function reset_sync_batch() {
		global $wpdb;

		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'linkboss_nonce' ) ) {
			echo wp_json_encode(
				array(
					'status' => 'error',
					'title'  => 'Error!',
					'msg'    => esc_html__( 'Failed to insert data. Please refresh your browser. If that doesn\'t work, please contact support team.', 'linkboss' ),
				)
			);
			wp_die();
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}linkboss_sync_batch" );

		echo wp_json_encode(
			array(
				'status' => 'success',
				'title'  => 'Success!',
				'msg'    => esc_html__( 'Congrats, the sync batch was reset successfully.', 'linkboss' ),
			)
		);
		wp_die();
	}
}