<?php
/**
 * Render Handler
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Description of Render
 * 
 * @since 0.0.0
 */
class Render {

	/**
	 * Construct
	 */
	public function __construct() {
		add_action( 'wp_ajax_linkbatch_batch_reports', [ $this, 'sync_batch_init_reports' ] );
	}
	public function _time_diff( $from, $to = '' ) {
		$diff    = human_time_diff( $from, $to );
		$replace = array(
			' hour'    => 'h',
			' hours'   => 'h',
			' day'     => 'd',
			' days'    => 'd',
			' minute'  => 'm',
			' minutes' => 'm',
			' second'  => 's',
			' seconds' => 's',
		);

		return strtr( $diff, $replace );
	}

	public function linkboss_time_diff( $data_time, $format = '' ) {
		$displayAgo = esc_html__( 'ago', 'linkboss' );

		if ( $format == 'short' ) {
			$output = $this->_time_diff( strtotime( $data_time ), current_time( 'timestamp' ) );
		} else {
			$output = human_time_diff( strtotime( $data_time ), current_time( 'timestamp' ) );
		}

		$output = $output . ' ' . $displayAgo;

		return $output;
	}
	/**
	 * Render the latest updated posts
	 * 
	 * @since 0.0.0
	 */
	public static function latest_updated_posts( $post_data ) {

		if ( ! $post_data ) {
			return;
		}

		foreach ( $post_data as $post ) {
			if ( empty( $post ) ) {
				return;
			}
			$post_title       = $post['title'];
			$post_link        = $post['url'];
			$post_update_date = $post['updatedAt'];

			$render_instance = new self();
			$converted_time  = $render_instance->linkboss_time_diff( $post_update_date );

			?>
			<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
				<th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
					<?php echo esc_html( $post_title ); ?>
					<div class="text-gray-500">
						<a target="_blank" href="<?php echo esc_url( $post_link ); ?>"
							title="Post ID - <?php echo esc_attr( $post['_postId'] ); ?>">
							<?php echo esc_url( $post_link ); ?>
						</a>
					</div>
				</th>
				<td class="px-6 py-4">
					<?php echo esc_html( $converted_time ); ?>
				</td>
			</tr>
			<?php
		}
	}

	/**
	 * Sync Batch Init Reports
	 * 
	 * @since 2.0.7
	 */
	public static function sync_batch_init_reports() {

		$reports = array();
		// get wordpress total page count
		$reports['pages'] = wp_count_posts( 'page' )->publish;
		// get wordpress total post count
		$reports['posts'] = wp_count_posts( 'post' )->publish;

		// get total sync batch count from wp_linkboss_sync_batch table
		global $wpdb;
		$table_name            = $wpdb->prefix . 'linkboss_sync_batch';
		$sql_sync              = "SELECT COUNT(*) FROM {$table_name}";
		$reports['sync_batch'] = $wpdb->get_var( $sql_sync );

		$sql_sync_done        = "SELECT COUNT(*) FROM {$table_name} where status IS NOT NULL";
		$reports['sync_done'] = $wpdb->get_var( $sql_sync_done );

		$sql_need_sync           = "SELECT COUNT(*) FROM {$table_name} where status IS NULL";
		$reports['require_sync'] = $wpdb->get_var( $sql_need_sync );

		// content size
		$sql_content_size        = "SELECT SUM(content_size) FROM {$table_name}";
		$content_size            = $wpdb->get_var( $sql_content_size );
		$reports['content_size'] = self::bytes_to_size( $content_size );

		return $reports;

		// echo wp_json_encode( array(
		// 	'status'  => 'success',
		// 	'message' => 'Reports Fetched Successfully',
		// 	'data'    => $reports,
		// ), true );
		// wp_die();
	}

	/**
	 * Bytes to Size
	 */
	public static function bytes_to_size( $bytes, $precision = 2 ) {
		$kilobyte = 1024;
		$megabyte = $kilobyte * 1024;
		$gigabyte = $megabyte * 1024;
		$terabyte = $gigabyte * 1024;

		if ( ( $bytes >= 0 ) && ( $bytes < $kilobyte ) ) {
			return $bytes . ' B';
		} elseif ( ( $bytes >= $kilobyte ) && ( $bytes < $megabyte ) ) {
			return round( $bytes / $kilobyte, $precision ) . ' KB';
		} elseif ( ( $bytes >= $megabyte ) && ( $bytes < $gigabyte ) ) {
			return round( $bytes / $megabyte, $precision ) . ' MB';
		} elseif ( ( $bytes >= $gigabyte ) && ( $bytes < $terabyte ) ) {
			return round( $bytes / $gigabyte, $precision ) . ' GB';
		} elseif ( $bytes >= $terabyte ) {
			return round( $bytes / $terabyte, $precision ) . ' TB';
		} else {
			return $bytes . ' B';
		}
	}
}