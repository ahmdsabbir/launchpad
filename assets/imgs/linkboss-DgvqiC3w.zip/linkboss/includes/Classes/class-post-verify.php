<?php
/**
 * Post Verify Handler
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use LinkBoss\Traits\Global_Functions;

/**
 * Description of Post Verify
 * 
 * @since 0.0.0
 */
class Post_Verify {

	use Global_Functions;

	private static $instance = null;

	/**
	 * Construct
	 * 
	 * @since 0.0.0
	 */
	function __construct() {
		add_action( 'init', array( $this, 'init_transient' ) );
		add_action( 'publish_post', array( $this, 'save_post_ids' ), 10, 2 );
		add_action( 'transition_post_status', array( $this, 'save_post_ids' ), 10, 3 );
		add_action( 'wp_trash_post', array( $this, 'save_post_ids' ) );
		add_action( 'delete_post', array( $this, 'save_post_ids' ) );
	}

	/**
	 * Get Instance
	 * 
	 * @since 0.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Latest post ids compare with transient post ids
	 * 
	 * @since 0.0.0
	 * true means no changes post ids & no need to sync
	 * false means changes post ids & need to sync
	 * @return boolean
	 */
	public static function compare_post_ids() {
		$post_ids_transient = self::get_post_ids_from_transient();
		$reports            = get_transient( 'linkboss_reports' );
		$post_ids_server    = isset( $reports->recents ) ? $reports->recents : array();

		sort( $post_ids_transient );
		sort( $post_ids_server );

		$diff = array_diff( $post_ids_transient, $post_ids_server );

		if ( empty( $diff ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Transient init if not exists or expired
	 * 
	 * @since 0.0.0
	 */
	public function init_transient() {
		if ( false === get_transient( 'linkboss_latest_post_ids' ) ) {
			$this->save_post_ids();
		}
	}

	/**
	 * Delete transient
	 * 
	 * @since 0.0.0
	 */
	public function delete_transient() {
		delete_transient( 'linkboss_latest_post_ids' );
	}

	/**
	 * Save the post ids in the database transient for 6 hours
	 * 
	 * @since 0.0.0
	 */
	public function save_post_ids() {
		$this->delete_transient();
		$post_ids = $this->get_latest_post_ids();
		set_transient( 'linkboss_latest_post_ids', $post_ids, 7 * HOUR_IN_SECONDS );
	}

	/**
	 * Get the post ids from the database transient
	 * 
	 * @since 0.0.0
	 */
	public static function get_post_ids_from_transient() {
		$post_ids = get_transient( 'linkboss_latest_post_ids' );
		return $post_ids;
	}

	/**
	 * Get the post ids from latest 10 posts
	 * 
	 * @since 0.0.0
	 */
	public function get_latest_post_ids() {
		$args      = array(
			'post_type'      => 'post',
			'posts_per_page' => 10,
			'post_status'    => 'publish',
			'fields'         => 'ids',
		);
		$posts_ids = get_posts( $args );
		return $posts_ids;
	}

}

// if ( class_exists( 'LinkBoss\Classes\Post_Verify' ) ) {
// 	\LinkBoss\Classes\Post_Verify::get_instance();
// }