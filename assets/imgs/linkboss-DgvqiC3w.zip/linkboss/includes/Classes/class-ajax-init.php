<?php
/**
 * Ajax Init Handler
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description of Init
 * 
 * @since 0.0.0
 */
class Ajax_Init {

	private static $instance = null;

	/**
	 * Get Instance
	 * 
	 * @since 0.0.0
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Construct
	 * 
	 * @since 0.0.0
	 */
	public function __construct() {
		add_action( 'wp_ajax_linkboss_sync_batch', [ $this, 'init_table_ids_for_batch' ] );
	}

	/**
	 * Init Table IDs
	 */
	public static function init_table_ids_for_batch() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'linkboss_sync_batch';

		$sql = "SELECT p.ID, p.post_type, p.post_content, p.post_status
				FROM {$wpdb->prefix}posts p
				LEFT JOIN {$wpdb->prefix}linkboss_sync_batch l ON p.ID = l.post_id
				WHERE l.post_id IS NULL
				AND p.post_type IN ('post', 'page')
				AND p.post_status = 'publish' LIMIT 100";

		$posts = $wpdb->get_results( $sql, ARRAY_A );

		// Split the data into batches of 100
		$batches = array_chunk( $posts, 200 );

		$totalBatches = count( $batches );
		$currentBatch = 0;

		foreach ( $batches as $batch ) {
			// Create the SQL query for inserting
			$insertSql = "INSERT IGNORE INTO $table_name (post_id, post_type, post_status, content_size) VALUES ";

			// Use the array values to construct the query
			$values = [];

			foreach ( $batch as $post ) {
				$post_id      = $post['ID'];
				$post_content = $post['post_content'];
				$post_type    = $post['post_type'];
				$post_status  = $post['post_status'];
				$content_size = mb_strlen( $post_content, '8bit' ); // Calculate size in bytes

				// Escape and include the post_id, post_type, and content size in the query
				$values[] = "($post_id, '$post_type', '$post_status', $content_size)";
			}

			// Combine the values and execute the query
			$insertSql .= implode( ', ', $values );
			$wpdb->query( $insertSql );

			// Update progress
			$currentBatch++;
		}

		if ( $totalBatches > 0 ) {
			echo wp_json_encode(
				array(
					'status'   => 'success',
					'has_post' => true,
					'msg'      => esc_html__( 'Batch Synced', 'linkboss' ),
				),
				true
			);
		} else {
			echo wp_json_encode(
				array(
					'status'   => 'success',
					'has_post' => false,
					'msg'      => esc_html__( 'No new posts to sync', 'linkboss' ),
				),
				true
			);
		}
		wp_die();
	}

}

if ( class_exists( 'LinkBoss\Classes\Ajax_Init' ) ) {
	\LinkBoss\Classes\Ajax_Init::get_instance();
}