<?php
/**
 * Activator class
 * 
 * @package LinkBoss
 * @since 0.0.6
 */

namespace LinkBoss;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly


use LinkBoss\Base\LinkBossBase;

class LinkBoss_Activator {
	public $plugin_file = LINKBOSS_PLUGIN__FILE__;
	public $responseObj;
	public $licenseMessage;
	public $showMessage = false;
	public $slug = "linkboss";
	function __construct() {
		// $licenseKey = get_option( "linkBoss_lic_key", "ABF7E20D-4744EBC3-1BA5B052-974D2511" );
		// $liceEmail  = get_option( "linkBoss_lic_email", get_bloginfo( 'admin_email' ) );


		$licenseKey = get_option( "LinkBoss_lic_Key", "ABF7E20D-4744EBC3-1BA5B052-974D2511" ); //any option name, by which name have saved the license code into option table
		$liceEmail  = get_option( "LinkBoss_lic_email", get_bloginfo( 'admin_email' ) ); //any option name, by which name have saved the license email into option table
		LinkBossBase::addOnDelete( function () {
			delete_option( "LinkBoss_lic_Key" );
		} );

		if ( LinkBossBase::CheckWPPlugin( $licenseKey, $liceEmail, $error, $responseObj, LINKBOSS_PLUGIN__FILE__ ) ) {
		}
	}
}

if ( class_exists( 'LinkBoss\LinkBoss_Activator' ) ) {
	new \LinkBoss\LinkBoss_Activator();
}