<?php
/*
 * Plugin Name: LinkBoss (Smartest Ever Interlinking Tool)
 * Plugin URI: https://linkboss.io
 * Description: LinkBoss Authenticator Plugin.
 * Version: 2.1.0
 * Requires at least: 5.2
 * Requires PHP: 7.2
 * Author: ZVENTURES LLC
 * Author URI: https://zventures.io/
 * 
 * @package LinkBoss
 * @author LinkBoss <hi@zventures.io>
 * @since 0.0.0
 * 
 */

/**
 * Prevent direct access
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LINKBOSS_VERSION', '2.1.0' );
define( 'LINKBOSS_PLUGIN__FILE__', __FILE__ );
define( 'LINKBOSS_PLUGIN_PATH', plugin_dir_path( LINKBOSS_PLUGIN__FILE__ ) );
define( 'LINKBOSS_PLUGIN_URL', plugins_url( '/', LINKBOSS_PLUGIN__FILE__ ) );
define( 'LINKBOSS_PLUGIN_INC_PATH', LINKBOSS_PLUGIN_PATH . 'includes/' );
define( 'LINKBOSS_PLUGIN_ASSETS_URL', LINKBOSS_PLUGIN_URL . 'assets/' );

define( 'LINKBOSS_REMOTE_URL', 'https://api.linkboss.io/api/plugin/' );
define( 'LINKBOSS_AUTH_URL', LINKBOSS_REMOTE_URL . 'auth/' );
define( 'LINKBOSS_FETCH_REPORT_URL', LINKBOSS_REMOTE_URL . 'options' );
define( 'LINKBOSS_POSTS_SYNC_URL', LINKBOSS_REMOTE_URL . 'sync' );
define( 'LINKBOSS_OPTIONS_URL', LINKBOSS_REMOTE_URL . 'options' );

/**
 * Installer
 *
 * @since 1.0.0
 */
require_once LINKBOSS_PLUGIN_PATH . 'includes/class-installer.php';
require_once LINKBOSS_PLUGIN_PATH . 'base/base.php';

// if ( is_admin() ) {
require_once LINKBOSS_PLUGIN_PATH . 'base/activator.php';
// }


/**
 * The main function responsible for returning the one true LinkBoss instance to functions everywhere.
 * 
 * @since 0.0.0
 */

if ( ! function_exists( 'linkboss' ) ) {
	function linkboss() {
		require_once __DIR__ . '/plugin.php';
	}

	function linkboss_activate() {
		$installer = new LinkBoss\Installer();
		$installer->run();
	}

	register_activation_hook( __FILE__, 'linkboss_activate' );

	linkboss();
}