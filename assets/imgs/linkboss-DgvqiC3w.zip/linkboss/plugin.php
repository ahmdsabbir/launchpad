<?php
/**
 * Plugin File
 * 
 * @package LinkBoss
 * @since 0.0.0
 */

namespace LinkBoss;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin class
 * 
 * @since 0.0.0
 */

final class Plugin {

	/**
	 * Require Files
	 *
	 * @return void
	 */
	public function includes_files() {
		require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-init.php';
		require_once LINKBOSS_PLUGIN_INC_PATH . 'Traits/global-functions.php';
		require_once LINKBOSS_PLUGIN_INC_PATH . 'class-admin.php';
		require_once LINKBOSS_PLUGIN_INC_PATH . 'Admin/class-layouts.php';
		require_once LINKBOSS_PLUGIN_INC_PATH . 'Admin/class-menu.php';
		require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-auth.php';
		require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-settings.php';
		require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-render.php';
		require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-ajax-init.php';

		$api_valid = get_option( 'linkboss_api_key', false );

		if ( $api_valid ) {
			/**
			 * Created by Prapon request RUN class.
			 * Not used
			 */
			require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-run.php';

			require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-posts.php';
			require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-update-posts.php';
			require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-updates.php';
			require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-post-verify.php';
			require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-fetch.php';
			require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-cron.php';
			require_once LINKBOSS_PLUGIN_INC_PATH . 'Classes/class-ajax-sync.php';
		}
	}
	/**
	 * Init Plugin
	 * 
	 * @since 0.0.0
	 * @return void
	 */
	public function init() {
		$this->includes_files();
		new Admin();
	}

	/**
	 * Enqueue Styles
	 * 
	 * @since 0.0.0
	 */
	public function enqueue_admin_styles() {
		$direction_suffix = is_rtl() ? '.rtl' : '';
		wp_enqueue_style( 'linkboss-tailwind', LINKBOSS_PLUGIN_ASSETS_URL . 'css/tailwind' . $direction_suffix . '.min.css', array(), LINKBOSS_VERSION );
		wp_enqueue_style( 'lb-datatable', LINKBOSS_PLUGIN_ASSETS_URL . 'vendor/css/dataTables.tailwindcss.min.css', array(), '1.13.7' );
		wp_enqueue_style( 'linkboss', LINKBOSS_PLUGIN_ASSETS_URL . 'css/linkboss' . $direction_suffix . '.min.css', array(), LINKBOSS_VERSION );
	}

	/**
	 * Enqueue Scripts
	 * 
	 * @since 0.0.0
	 */
	public function enqueue_admin_scripts() {
		/**
		 * Vendor JS Files
		 */
		wp_enqueue_script( 'lb-datatable', LINKBOSS_PLUGIN_ASSETS_URL . 'vendor/js/jquery.dataTables.min.js', array( 'jquery' ), '1.13.7', true );
		wp_enqueue_script( 'lb-datatable', LINKBOSS_PLUGIN_ASSETS_URL . 'vendor/js/dataTables.tailwindcss.js', array( 'jquery' ), '1.13.7', true );
		wp_enqueue_script( 'lb-vendor', LINKBOSS_PLUGIN_ASSETS_URL . 'vendor/socket.io.min.js', array(), LINKBOSS_VERSION, true );

		/**
		 * Main JS File
		 */
		wp_enqueue_script( 'linkboss', LINKBOSS_PLUGIN_ASSETS_URL . 'js/linkboss.js', array( 'jquery' ), LINKBOSS_VERSION, true );

		$script_config = array(
			'ajaxurl'   => admin_url( 'admin-ajax.php' ),
			'nonce'     => wp_create_nonce( 'linkboss_nonce' ),
			'activated' => get_option( 'linkboss_api_key', false ),
		);

		$access_token = get_transient( 'linkboss_access_token' );

		wp_localize_script( 'linkboss', 'LinkbossConfig', $script_config );
		wp_localize_script( 'linkboss', 'LinkbossSocket', array(
			'access_token' => $access_token,
		) );
	}

	/**
	 * Setup Hooks
	 * 
	 * @since 0.0.0
	 */
	private function setup_hooks() {

		if ( isset( $_GET['page'] ) && $_GET['page'] == 'linkboss' ) {
			add_action( 'admin_init', array( $this, 'enqueue_admin_styles' ), 99999 );
			add_action( 'admin_init', array( $this, 'enqueue_admin_scripts' ), 99999 );
		}
		if ( isset( $_GET['page'] ) && $_GET['page'] == 'linkboss-settings' ) {
			add_action( 'admin_init', array( $this, 'enqueue_admin_styles' ), 99999 );
			add_action( 'admin_init', array( $this, 'enqueue_admin_scripts' ), 99999 );
		}

	}

	/**
	 * Constructor
	 * 
	 * @since 0.0.0
	 */
	public function __construct() {
		$this->init();
		$this->setup_hooks();
	}
}

// kick off the plugin
if ( class_exists( 'LinkBoss\Plugin' ) ) {
	new Plugin();
}